setwd("Q:/comparison study/NORDCAN")

#ggplot plots
library(ggplot2)
library(grid)
library(gridExtra)


# Denamrk 1980-1990-2000-2010, incidence for testis cancer (male)
# 5-years age grouping, intervals with equal bins

load("pclm5_dkiTestis.RData") #pclm
load("bkde5_dkiTestis.RData") #bKDE
load("ickde5_dkiTestis.RData") #ickde
load("cmspline5_dkiTestis.RData") #cm.spline
load("pch5_dkiTestis.RData") #pch
load("true_dkiTestis.RData") #ID


# data preparation
Age <- rep(0:94,6)
Method <- c(rep("empirical data", length(Age)/6), rep("pclm", length(Age)/6), rep("bootkde", length(Age)/6), rep("ickde", length(Age)/6),
            rep("hyman spline", length(Age)/6), rep("hermite spline", length(Age)/6))
Fit <- c(rep(NA,95), pclm, bKDE, ickde, cm.spline, pch)
True <- ID
data_f <- data.frame(Age=Age, Method=Method, Fit=Fit)
data_t <- data.frame(Age=0:94,True=True)

grouped_counts <- c(rep(1:19, each=5))
a_g <- aggregate (data_t$True, by=list(grouped_counts), FUN="sum")
y <- a_g$x #assumed observed aggregated deaths counts 
Y <- y/5
Hist <- rep(Y, each=5)
data_h <- data.frame(Age=0:94, Hist=Hist)
 

# plots
data_f$Method <- factor(data_f$Method,
                        levels = c("empirical data", "bootkde", "hermite spline",
                                   "hyman spline", "ickde", "pclm"))


pdf(file="dkiTestis5.pdf", width=27, height=7,paper="a4r") 

ggplot(data_f, aes(x=Age)) +
  geom_histogram(aes(y=Hist), data=data_h, stat="identity", col="gray75", fill="gray75")+
  geom_line(aes(y=True), data=data_t, size=1, colour="gray40") +
  geom_point(aes(y=True), data=data_t, size=2.1, colour="gray40") +
  geom_line(aes(y=Fit), data=data_f, size=1.3, col="black")+
  scale_y_continuous("No. of Diagnoses") + 
  facet_wrap(~ Method) +
  theme(#plot.title = element_text(size = 11),
    axis.text=element_text(size=10),
    axis.title=element_text(size=11),
    strip.text.x = element_text(size = 11))

dev.off()



